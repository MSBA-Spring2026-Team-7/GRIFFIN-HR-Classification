# Reference Data Test Kit
## For testing the Classification Prompt Template

### What's included

1. **classification_prompt_template_v1.md** - The prompt template. Copy the PROMPT section into a clean LLM session.

2. **career_groups.csv** - Career group descriptions with concepts of work.
   CURRENT STATUS: Only Financial Services (#19030) is populated. Remaining ~55 groups need to be scraped.

3. **roles.csv** - Role descriptions with all three compensable factors (Complexity, Results, Accountability).
   CURRENT STATUS: All 7 Financial Services roles populated (Specialist I-III, Manager I-IV).

4. **historical_titles.csv** - Legacy class title mappings to current roles.
   CURRENT STATUS: All 59 Financial Services historical titles populated.

5. **wm_salary_structure.csv** - W&M university pay grades (S01-S23, H01-H23) with min/midpoint/max.
   CURRENT STATUS: Complete.

6. **soc_codes.csv** - SOC code mappings at both career group and role levels.
   CURRENT STATUS: Financial Services only.

7. **wm_hr_classification_schema.sql** - Full MySQL database schema (9 tables, views, sample data). Open in MySQL Workbench.

### What's NOT yet included (still to build)

- DHRM pay band structure (need to parse the FY26 PDF)
- DHRM-to-W&M pay band crosswalk table
- Career groups beyond Financial Services (50 HTML pages + 6 PDFs to scrape)

### How to run a clean test

1. Open a FRESH LLM session (new Claude conversation, or Copilot, or Gemini) with NO prior context about this project
2. Paste the prompt template
3. Attach or paste the CSV reference files
4. Paste a W&M position description
5. See what comes out

### Important limitation for testing

Because only Financial Services is currently populated, your best test case is a finance-related W&M posting (accounting, budget, financial reporting, audit, treasury, grants). A non-finance posting (e.g., IT, HR, facilities) will not have matching career group data and the LLM will either fail to classify or guess without evidence.

Once we scrape the remaining career groups, you can test against any W&M position.
